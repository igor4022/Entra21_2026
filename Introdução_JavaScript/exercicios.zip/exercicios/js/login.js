export default function salvar() {
    const nome = document.querySelector('#nome');
    const form = document.querySelector('#formulario');
    
    prompt('Digite seu nome:');
    alert(`Olá, ${nome.value}! Seja bem-vindo!`);
    console.log(`O nome do usuário é: ${nome.value}`);

    if (!nome || !form) return;
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const nomeDigitado = nome.value;
        localStorage.setItem('nome', nomeDigitado);
        window.location.href = 'conteudo.html'; 
    })
}

salvar();