import conteudo from "./js/conteudo.js";
import salvar from "./js/login.js";

conteudo();
salvar();